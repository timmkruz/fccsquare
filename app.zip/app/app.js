const express = require('express')
const app = express()
const port = 3080
require('dotenv').config();

//fullcircleassessments.ca/register/{firstname}/{lastname}/{email}/{quiz1}/{quiz2}/{quiz3}/
const { Client, Environment, ApiError } = require("square");

const client = new Client({
  bearerAuthCredentials: {
    accessToken: 'EAAAl-eMUVnOAJkguP7zE96gJrrJcl_EzFa2V89VhtueGgOkM05DOg36e1j7Lm7F'
  },
  environment: Environment.Production,
});

//First Get Info About Order
//Then GetQuantity
//Finally return URL


function generateUrl(lineItem,firstname,lastname,email) {
    // Datos básicos para la URL
    let baseUrl = "https://www.fullcircleassessments.ca/register/{firstname}/{lastname}/{email}/{180}/{self}/{360}/";
    let quantity = parseInt(lineItem.quantity);

    // Reemplazar los valores según el nombre del ítem
    if (lineItem.name === "180 Assessment") {
        return baseUrl.replace("{firstname}", firstname)
                      .replace("{lastname}", lastname)
                      .replace("{email}", email)
                      .replace("{180}", quantity)
                      .replace("{self}", "0")
                      .replace("{360}", "0");
    } else if (lineItem.name === "360 Assessment") {
        return baseUrl.replace("{firstname}", firstname)
                      .replace("{lastname}", lastname)
                      .replace("{email}", email)
                      .replace("{180}", "0")
                      .replace("{self}", "0")
                      .replace("{360}", quantity);
    } else if (lineItem.name === "Self-assessment") {
        return baseUrl.replace("{firstname}", firstname)
                      .replace("{lastname}", lastname)
                      .replace("{email}", email)
                      .replace("{180}", "0")
                      .replace("{self}", quantity)
                      .replace("{360}", "0");
    } else {
        return "Item name does not match any special case.";
    }
}



app.post('/squareup', async (req, res) => {
    console.log(`Received request at ${new Date().toISOString()}`);
    let orderId;
    var paymentId
    try { 
        const rs = req.body;
        orderId = rs.data.object.payment.order_id;
        console.log("Order ID:", orderId);
        
        
    } catch (error) {
        console.error("Error extracting order ID:", error.message || error);
        return res.status(500).send({ error: error.message || "Error processing request" });
    }



    //GET ORDEN

    try {
        var test = orderId
        const { result } = await client.ordersApi.retrieveOrder(test);
        const jsonString = JSON.stringify(result, (key, value) =>
          typeof value === 'bigint' ? value.toString() : value
        );
        var jx = JSON.parse(jsonString)
        console.log(jx)
        
        //res.send(url);

    } catch (error) {
        console.error("Error retrieving order:", error.message || error);
        return res.status(500).send({ error: error.message || "Error retrieving order" });
    }


   
    // GET FULL Payment
    try {
        const fs = await client.paymentsApi.getPayment(req.body.data.object.payment.id);
        const paymt = JSON.stringify(fs, (key, value) =>
          typeof value === 'bigint' ? value.toString() : value
        );
        var paymtjx = JSON.parse(paymt)
      } catch(error) {
        console.log(error);
      }


      //GET COSTUMER FROM COSTUMER ID

      try {
  const CostumerGet = await client.customersApi.retrieveCustomer(paymtjx.result.payment.customerId);

  const costumer = JSON.stringify(CostumerGet, (key, value) =>
          typeof value === 'bigint' ? value.toString() : value
        );
        var costumjx = JSON.parse(costumer)
  

        var url = generateUrl(jx.order.lineItems[0],costumjx.result.customer.givenName,costumjx.result.customer.familyName,costumjx.result.customer.emailAddress)
        console.log("============FINAL RESPONSE =========")
        console.log(url)
        const das = await axios.get(url);

        res.send("Finish")
} catch(error) {
  console.log(error);
}
});



//First i will get info about costumer to get the costumer ID
//Then i will get orders from Costumer with param of costumer ID


app.listen(port, () => {
  console.log(` app listening on port ${port}`)
})